module.exports = require("./makewebpackconfig")({
  prod: true
});