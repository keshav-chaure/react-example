module.exports = require("./makewebpackconfig")({
  prod: false
});